export interface ItemEnchereProps {
    enchere: any
}

