export const baseUrl = "http://localhost:3000";

