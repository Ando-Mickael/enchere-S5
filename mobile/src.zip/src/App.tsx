import { Redirect, Route } from 'react-router-dom';
import {
	IonApp,
	IonIcon,
	IonLabel,
	IonRouterOutlet,
	IonTabBar,
	IonTabButton,
	IonTabs,
	setupIonicReact
} from '@ionic/react';
import { IonReactRouter } from '@ionic/react-router';

/* Core CSS required for Ionic components to work properly */
import '@ionic/react/css/core.css';

/* Basic CSS for apps built with Ionic */
import '@ionic/react/css/normalize.css';
import '@ionic/react/css/structure.css';
import '@ionic/react/css/typography.css';

/* Optional CSS utils that can be commented out */
import '@ionic/react/css/padding.css';
import '@ionic/react/css/float-elements.css';
import '@ionic/react/css/text-alignment.css';
import '@ionic/react/css/text-transformation.css';
import '@ionic/react/css/flex-utils.css';
import '@ionic/react/css/display.css';

/* Theme variables */
import './theme/variables.css';

/* My imports */
import { home, person } from 'ionicons/icons';
import { Accueil } from './pages/Accueil';
import { Profil } from './pages/Profil';
import { Inscription } from './pages/Inscription';
import { DemandeRecharge} from './pages/DemandeRecharge';
import { Login } from './pages/Login';
import { AjoutEnchere} from './pages/AjoutEnchere';

setupIonicReact();

const App: React.FC = () => (
	<IonApp>
		<IonReactRouter>
			<IonTabs>
				<IonRouterOutlet>
					<Route exact path="/accueil">
						<Accueil />
					</Route>
					<Route exact path="/profil">
						<Profil />
					</Route>
					<Route exact path="/">
						<Redirect to="/accueil" />
					</Route>
					<Route exact path="/inscription">
						<Inscription />
					</Route>
					<Route exact path="/ajoutenchere">
						<AjoutEnchere />
					</Route>
					<Route exact path="/demanderecharge">
						<DemandeRecharge />
					</Route>
					<Route exact path="/login">
						<Login />
					</Route>
					

				</IonRouterOutlet>
				<IonTabBar slot="bottom">
					<IonTabButton tab="accueil" href="/accueil">
						<IonIcon icon={home} />
						<IonLabel>Accueil</IonLabel>
					</IonTabButton>
					
					<IonTabButton tab="login" href="/login">
						<IonIcon icon={person} />
						<IonLabel>Login</IonLabel>
					</IonTabButton>
					
					<IonTabButton tab="inscription" href="/inscription">
						<IonIcon icon={person} />
						<IonLabel>Inscription</IonLabel>
					</IonTabButton>

					<IonTabButton tab="profil" href="/profil">
						<IonIcon icon={person} />
						<IonLabel>Profil</IonLabel>
					</IonTabButton>

					
					<IonTabButton tab="AjoutEnchere" href="/ajoutenchere">
						<IonIcon icon={person} />
						<IonLabel>AjoutEnchere</IonLabel>
					</IonTabButton>

					<IonTabButton tab="DemandeRecharge" href="/demanderecharge">
						<IonIcon icon={person} />
						<IonLabel>DemandeRecharge</IonLabel>
					</IonTabButton>
				</IonTabBar>
			</IonTabs>
		</IonReactRouter>
	</IonApp>
);

export default App;
