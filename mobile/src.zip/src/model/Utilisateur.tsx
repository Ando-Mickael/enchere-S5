import axios from "axios";
import { baseUrl } from "../util/Api";

export default class Utilisateur {
    
    private __nom?:string;
    private __pseudo?: string;

    public constructor(nom: any, pseudo: any) {
        this.__nom = nom;
        this.__pseudo = pseudo;
    }

    public login() {
        const url = baseUrl + "/inscription";
        axios.post(url, {
            "nom": this.__nom,
            "pseudo": this.__pseudo
        })
            .then((response) => {
                console.log(response);
            })
            .catch((err) => {
                console.log(err)
            });
    }



}