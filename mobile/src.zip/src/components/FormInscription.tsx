import { IonButton, IonInput, IonItem } from "@ionic/react";
import { useState } from "react";
import Utilisateur from "../model/Utilisateur";
import Personne from "../model/Personne";

export const FormInscription: React.FC = () => {

    const [nom, setNom] = useState();
    const [pseudo, setPseudo] = useState();
    const [email, setEmail] = useState();
    const [mpd, setMdp] = useState();

    const verifLogin = () => {
        const utilisateur = new Utilisateur(nom, pseudo);
        utilisateur.login();
    }

    return (
        <>
            
            <IonItem>
                <IonInput
                   
                   placeholder="nom"
                    onIonChange={(e: any) => setNom(e.target.value)} />
            </IonItem>

            <IonItem>
                <IonInput
                    placeholder="Pseudo"
                    onIonChange={(e: any) => setPseudo(e.target.value)} />
            </IonItem>

            
            <IonItem>
                <IonInput
                    placeholder="Email"
                    onIonChange={(e: any) => setEmail(e.target.value)} />
            </IonItem>

            <IonItem>
                <IonInput
                    placeholder="Mot de passe"
                    type="password"
                    onIonChange={(e: any) => setMdp(e.target.value)} />
            </IonItem>


            <IonButton
                expand="block"
                onClick={() => verifLogin()}>Inscription</IonButton>
        </>
    );
} 