import { IonItem, IonThumbnail, IonLabel } from "@ionic/react";
import { ItemEnchereProps } from "../util/Interface";

export const ItemEnchere: React.FC<ItemEnchereProps> = ({enchere}) => {

    return (
        <IonItem>
            <IonThumbnail slot="start">
                <img src="https://ionicframework.com/docs/img/demos/thumbnail.svg" />
            </IonThumbnail>
            <IonLabel>
                Thumbnail Item
            </IonLabel>
        </IonItem>
    );
}