import { IonButton, IonInput, IonItem, IonLabel } from "@ionic/react";
import { useState } from "react";
import Utilisateur from "../model/Utilisateur";

export const FormProfil: React.FC = () => {

    // const [nom, getNom] = useState();
    // const [Pseudo, getPseudo] = useState();


    return (
        <>
            <IonItem>
                <IonLabel> <h1>Jean Rakoto</h1></IonLabel>
            </IonItem>

            <IonItem>
                <IonLabel>jeanrakoto@gmail.com</IonLabel>
            </IonItem>

            <IonItem>
                <IonLabel>Mon compte : 100000 ariary</IonLabel>
            </IonItem>

            <IonButton
                expand="block">Recharger</IonButton>
           
           
            <IonItem>
                <IonLabel>
                    <h2>Mes encheres :</h2>
                </IonLabel>
            </IonItem>

            <IonItem>
                <IonLabel>
                    Tableau
                    <p>"oeuvre d'art"<br />status : fin</p>
                </IonLabel>
            </IonItem>

            <IonItem>
                <IonLabel>
                    Smartphone
                    <p>"Technologie"<br />status : en cours</p>
                </IonLabel>
            </IonItem>

        </>
    );
} 