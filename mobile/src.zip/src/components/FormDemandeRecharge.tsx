import { IonButton, IonInput, IonItem } from "@ionic/react";
// import { useState } from "react";
// import Utilisateur from "../model/Utilisateur";


export const FormDemandeRecharge: React.FC = () => {

    // const [nom, setNom] = useState();
    // const [pseudo, setPseudo] = useState();
    
    // const verifLogin = () => {
    //     const utilisateur = new Utilisateur(nom, pseudo);
    //     utilisateur.login();
    // }

    return (
        <>
            
            <IonItem>
                <IonInput
                   
                   placeholder="Montant"/>
            </IonItem>
{/* 
            <IonItem>
                <IonInput
                    placeholder="Pseudo"
                    onIonChange={(e: any) => setPseudo(e.target.value)} />
            </IonItem>

            
            <IonItem>
                <IonInput
                    placeholder="Email"
                    onIonChange={(e: any) => setEmail(e.target.value)} />
            </IonItem>

            <IonItem>
                <IonInput
                    placeholder="Mot de passe"
                    type="password"
                    onIonChange={(e: any) => setMdp(e.target.value)} />
            </IonItem> */}


            <IonButton
                expand="block">Recharger</IonButton>
        </>
    );
} 