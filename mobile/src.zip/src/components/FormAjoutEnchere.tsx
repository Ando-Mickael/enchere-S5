import { IonButton, IonInput, IonItem, IonLabel } from "@ionic/react";
import { IonDatetime } from '@ionic/react';



export const FormAjoutEnchere: React.FC = () => {

    // const [nom, getNom] = useState();
    // const [Pseudo, getPseudo] = useState();


    return (
        <>
            <IonItem>
                <IonLabel> <h1>Jean Rakoto</h1></IonLabel>
            </IonItem>

            <IonItem>
                <IonInput placeholder="nom"> </IonInput>
            </IonItem>

            <IonItem>
            <IonDatetime
      value="2022-04-21T00:00:00"
      min="2023-01-01T00:00:00"
      max="2023-12-31T23:59:59"
    ></IonDatetime>
            </IonItem>

           
           
            <IonItem>
            <IonDatetime
      value="2022-04-21T00:00:00"
      min="2023-01-01T00:00:00"
      max="2023-12-31T23:59:59"
    ></IonDatetime>
            </IonItem>

            <IonItem>
                <IonInput  placeholder="description"></IonInput>
            </IonItem>
            <IonButton
                expand="block">Ajouter</IonButton>
           

        </>
    );
} 