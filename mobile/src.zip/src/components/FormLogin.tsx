import { IonButton, IonInput, IonItem } from "@ionic/react";
import { useState } from "react";
import Personne from "../model/Personne";

export const FormLogin: React.FC = () => {

    const [email, setEmail] = useState();
    const [mdp, setMdp] = useState();

    const verifLogin = () => {
        const personne = new Personne(email, mdp);
        personne.login();
    }

    return (
        <>
            <IonItem>
                <IonInput
                   
                   placeholder="Email"
                    onIonChange={(e: any) => setEmail(e.target.value)} />
            </IonItem>

            <IonItem>
                <IonInput
                    placeholder="Mot de passe"
                    type="password"
                    onIonChange={(e: any) => setMdp(e.target.value)} />
            </IonItem>

            <IonButton
                expand="block"
                onClick={() => verifLogin()}>Se connecter</IonButton>
        </>
    );
} 