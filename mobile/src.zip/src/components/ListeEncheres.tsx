import { IonList, IonRefresher, IonRefresherContent, RefresherEventDetail } from "@ionic/react";
import axios from "axios";
import { useEffect, useState } from "react";
import { baseUrl } from "../util/Api";
import { ItemEnchere } from "./ItemEnchere";

export const ListeEncheres: React.FC = () => {

    const [encheres, setEncheres] = useState([]);

    const getEncheres = () => {
        const url = baseUrl + "/encheres";
        axios.get(url)
            .then((response) => {
                setEncheres(response.data);
            })
    }

    function handleRefresh(event: CustomEvent<RefresherEventDetail>) {
        setTimeout(() => {
            getEncheres();
            event.detail.complete();
        }, 2000);
    }

    useEffect(() => {
        getEncheres();
    }, []);

    return (
        <>
            <IonRefresher slot="fixed" onIonRefresh={handleRefresh}>
                <IonRefresherContent />
            </IonRefresher>
            <IonList>
                {encheres.map((enchere) => {
                    return (
                        <ItemEnchere enchere={enchere} key={enchere["id"]} />
                    );
                })}
            </IonList>
        </>
    );
}