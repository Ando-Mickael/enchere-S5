export const BtnConnexion: React.FC = () => {
    return (
        <></>
    );
}