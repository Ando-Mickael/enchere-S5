import { IonContent, IonHeader, IonPage, IonTitle, IonToolbar } from "@ionic/react";
import { BtnAjoutEnchere } from "../components/BtnAjoutEnchere";
import { FormDemandeRecharge } from "../components/FormDemandeRecharge";

export const DemandeRecharge: React.FC = () => {

    return (
        <IonPage>
            <IonHeader>
                <IonToolbar>
                    <IonTitle>DemandeRecharge</IonTitle>
                </IonToolbar>
            </IonHeader>
            <IonContent>
              <DemandeRecharge />
                <BtnAjoutEnchere />
            </IonContent>
        </IonPage>
    );
}