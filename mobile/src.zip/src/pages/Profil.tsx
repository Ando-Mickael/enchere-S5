import { IonContent, IonHeader, IonPage, IonTitle, IonToolbar } from "@ionic/react";
import { BtnAjoutEnchere } from "../components/BtnAjoutEnchere";
import { FormProfil } from "../components/FormProfil";

export const Profil: React.FC = () => {

    return (
        <IonPage>
            <IonHeader>
                <IonToolbar>
                    <IonTitle>Profil</IonTitle>
                </IonToolbar>
            </IonHeader>
            <IonContent>
                <FormProfil />
                <BtnAjoutEnchere />
            </IonContent>
        </IonPage>
    );
}