import { IonContent, IonHeader, IonPage, IonTitle, IonToolbar } from "@ionic/react";
import { FormAjoutEnchere } from "../components/FormAjoutEnchere";

export const AjoutEnchere: React.FC = () => {

    return (
        <IonPage>
            <IonHeader>
                <IonToolbar>
                    <IonTitle>AjoutEnchere</IonTitle>
                </IonToolbar>
            </IonHeader>
            <IonContent>
                <AjoutEnchere />
            </IonContent>
        </IonPage>
    );
}