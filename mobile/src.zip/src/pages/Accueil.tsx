// liste des encheres
import { IonButtons, IonContent, IonHeader, IonPage, IonTitle, IonToolbar } from '@ionic/react';
import { BtnAjoutEnchere } from '../components/BtnAjoutEnchere';

export const Accueil: React.FC = () => {

	return (
		<IonPage>
			<IonHeader>
				<IonToolbar>
					<IonTitle>Accueil</IonTitle>
					<IonButtons slot='end'>

					</IonButtons>
				</IonToolbar>
			</IonHeader>
			<IonContent>
				Liste des encheres
				<BtnAjoutEnchere />
			</IonContent>
		</IonPage>
	);
};
